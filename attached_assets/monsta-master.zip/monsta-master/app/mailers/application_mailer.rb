class ApplicationMailer < ActionMailer::Base
  default from: "admin-no-reply@myspacenyc.com"
  layout 'mailer'
end
